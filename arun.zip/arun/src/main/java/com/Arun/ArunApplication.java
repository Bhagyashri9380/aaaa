package com.Arun;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ArunApplication {

	public static void main(String[] args) {
		SpringApplication.run(ArunApplication.class, args);
	}

}
